import type AdminUi from '@mercurjs/core/modules/admin-ui'
import type Codegen from '@mercurjs/core/.medusa/server/src/modules/codegen'
import type Commission from '@mercurjs/core/.medusa/server/src/modules/commission'
import type CustomFields from '@mercurjs/core/.medusa/server/src/modules/custom-fields'
import type Media from '@mercurjs/core/.medusa/server/src/modules/media'
import type Offer from '@mercurjs/core/.medusa/server/src/modules/offer'
import type Payout from '@mercurjs/core/.medusa/server/src/modules/payout'
import type ProductAttribute from '@mercurjs/core/.medusa/server/src/modules/product-attribute'
import type ProductEdit from '@mercurjs/core/.medusa/server/src/modules/product-edit'
import type PromotionCost from '@mercurjs/core/.medusa/server/src/modules/promotion-cost'
import type Review from '@mercurjs/core/.medusa/server/src/modules/review'
import type Seller from '@mercurjs/core/.medusa/server/src/modules/seller'
import type VendorUi from '@mercurjs/core/modules/vendor-ui'
import type { IStockLocationService } from '@medusajs/framework/types'
import type { IInventoryService } from '@medusajs/framework/types'
import type { IProductModuleService } from '@medusajs/framework/types'
import type { IPricingModuleService } from '@medusajs/framework/types'
import type { IPromotionModuleService } from '@medusajs/framework/types'
import type { ICustomerModuleService } from '@medusajs/framework/types'
import type { ISalesChannelModuleService } from '@medusajs/framework/types'
import type { ICartModuleService } from '@medusajs/framework/types'
import type { IRegionModuleService } from '@medusajs/framework/types'
import type { IApiKeyModuleService } from '@medusajs/framework/types'
import type { IStoreModuleService } from '@medusajs/framework/types'
import type { ITaxModuleService } from '@medusajs/framework/types'
import type { ICurrencyModuleService } from '@medusajs/framework/types'
import type { IPaymentModuleService } from '@medusajs/framework/types'
import type { IOrderModuleService } from '@medusajs/framework/types'
import type { ISettingsModuleService } from '@medusajs/framework/types'
import type { IRbacModuleService } from '@medusajs/framework/types'
import type { IAuthModuleService } from '@medusajs/framework/types'
import type { IUserModuleService } from '@medusajs/framework/types'
import type { IFulfillmentModuleService } from '@medusajs/framework/types'
import type { INotificationModuleService } from '@medusajs/framework/types'
import type { ICacheService } from '@medusajs/framework/types'
import type { IEventBusModuleService } from '@medusajs/framework/types'
import type { IWorkflowEngineService } from '@medusajs/framework/types'
import type { ILockingModule } from '@medusajs/framework/types'
import type { IFileModuleService } from '@medusajs/framework/types'
import type Spike from '../../src/modules/spike'

declare module '@medusajs/framework/types' {
  interface ModuleImplementations {
    'admin_ui': InstanceType<(typeof AdminUi)['service']>,
    'codegen': InstanceType<(typeof Codegen)['service']>,
    'commission': InstanceType<(typeof Commission)['service']>,
    'custom_fields': InstanceType<(typeof CustomFields)['service']>,
    'media': InstanceType<(typeof Media)['service']>,
    'offer': InstanceType<(typeof Offer)['service']>,
    'payout': InstanceType<(typeof Payout)['service']>,
    'product_attribute': InstanceType<(typeof ProductAttribute)['service']>,
    'product_edit': InstanceType<(typeof ProductEdit)['service']>,
    'promotion_cost': InstanceType<(typeof PromotionCost)['service']>,
    'review': InstanceType<(typeof Review)['service']>,
    'seller': InstanceType<(typeof Seller)['service']>,
    'vendor_ui': InstanceType<(typeof VendorUi)['service']>,
    'stock_location': IStockLocationService,
    'inventory': IInventoryService,
    'product': IProductModuleService,
    'pricing': IPricingModuleService,
    'promotion': IPromotionModuleService,
    'customer': ICustomerModuleService,
    'sales_channel': ISalesChannelModuleService,
    'cart': ICartModuleService,
    'region': IRegionModuleService,
    'api_key': IApiKeyModuleService,
    'store': IStoreModuleService,
    'tax': ITaxModuleService,
    'currency': ICurrencyModuleService,
    'payment': IPaymentModuleService,
    'order': IOrderModuleService,
    'settings': ISettingsModuleService,
    'rbac': IRbacModuleService,
    'auth': IAuthModuleService,
    'user': IUserModuleService,
    'fulfillment': IFulfillmentModuleService,
    'notification': INotificationModuleService,
    'cache': ICacheService,
    'event_bus': IEventBusModuleService,
    'workflows': IWorkflowEngineService,
    'locking': ILockingModule,
    'file': IFileModuleService,
    'spike': InstanceType<(typeof Spike)['service']>
  }
}